import javax.persistence.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Driver {

	public static void main(String[] args) throws ParseException {
		//  Get Entity Manager and Transaction
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JavaPersistence");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		// Create individual Role objects
		Role analyst = new Role("Analyst");
		Role admin = new Role("Admin");
		Role manager = new Role("Manager");

		// Create individual Department objects
		Department IT = new Department("IT");
		Department sales = new Department("Sales");
		Department HR = new Department("HR");
		
		// Create individual Building objects
		Building chrysler = new Building("Chrysler", "New York");
		Building pavilion = new Building("Pavilion", "Camden");

		// Create individual Floor objects
		Floor seventeenth = new Floor("17th", 5, false, chrysler);
		Floor eighteenth = new Floor("18th", 3, true, chrysler);
		Floor nineteenth = new Floor("19th", 0, false, chrysler);
		Floor lobby = new Floor("Lobby", 0, true, pavilion);

		// Get a date format object to create Dates from Strings
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		
		// Create individual Employee objects
		Employee lucy = new Employee("Lucy", sdf.parse("06-Aug-2010"), IT, analyst);
		Employee ricky = new Employee("Ricky", sdf.parse("11-Dec-2012"), sales, admin);
		Employee fred = new Employee("Fred", sdf.parse("01-Jun-1990"), IT, manager);
		Employee ethel = new Employee("Ethel", sdf.parse("17-May-1997"), HR, admin);

		// Build the Employee Department list
		List<Employee> employeesIT = Arrays.asList(lucy, fred);
		List<Employee> employeesHR = Arrays.asList(ethel);
		List<Employee> employeesSales = Arrays.asList(ricky);
		
		// Build the Employee Role list
		List<Employee> employeesAdmin = Arrays.asList(ricky, ethel);
		List<Employee> employeesAnalyst = Arrays.asList(lucy);
		List<Employee> employeesManager = Arrays.asList(fred);
		
		// Build the Department list
		List<Department> departmentsChrysler = Arrays.asList(IT, HR);
		List<Department> departmentsPavilion = Arrays.asList(IT, sales);

		// Build the Building list
		List<Building> buildingsIT = Arrays.asList(chrysler, pavilion);
		List<Building> buildingsHR = Arrays.asList(chrysler);
		List<Building> buildingsSales = Arrays.asList(pavilion);
		
		// Build the Floor list
		List<Floor> floorsChrysler = Arrays.asList(seventeenth, eighteenth, nineteenth);
		List<Floor> floorsPavilion = Arrays.asList(lobby);
		
		// Set the Lists
		IT.setEmployees(employeesIT);
		IT.setBuildings(buildingsIT);
		
		HR.setEmployees(employeesHR);
		HR.setBuildings(buildingsHR);
		
		sales.setEmployees(employeesSales);
		sales.setBuildings(buildingsSales);
		
		chrysler.setFloors(floorsChrysler);
		chrysler.setDepartments(departmentsChrysler);
		
		pavilion.setFloors(floorsPavilion);
		pavilion.setDepartments(departmentsPavilion);
		
		admin.setEmployees(employeesAdmin);
		analyst.setEmployees(employeesAnalyst);
		manager.setEmployees(employeesManager);
		
		
		// Start to persist and commit data to database
		try {
			tx.begin();
			
			em.persist(analyst);
			em.persist(admin);
			em.persist(manager);
			
			em.persist(IT);
			em.persist(sales);
			em.persist(HR);
			
			em.persist(chrysler);
			em.persist(pavilion);
			
			em.persist(seventeenth);
			em.persist(eighteenth);
			em.persist(nineteenth);
			em.persist(lobby);
			
			em.persist(lucy);
			em.persist(ricky);
			em.persist(fred);
			em.persist(ethel);
						
			tx.commit();
			
			System.out.println("Completed");
		}
		catch(Exception e) {
			System.out.println("\n *** Error committing to database. ***");
			System.out.println(e.getMessage() + "\n");
		}	
		
		em.close();
		emf.close();
	}
	
}
