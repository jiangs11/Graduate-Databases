import java.io.Serializable;
import javax.persistence.*;
import java.util.*;

/**
 * Entity implementation class for Entity: Department
 *
 */
@Entity
public class Department implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long departmentID;
	
	private String departmentName;
	
	@OneToMany
	@JoinTable(name = "employee_department",
	   		   joinColumns = @JoinColumn(name = "departmentID"),
	   		   inverseJoinColumns = @JoinColumn(name = "employeeID"))
	private List<Employee> employees;
	
	@ManyToMany
	@JoinTable(name = "department_building",
			   joinColumns = @JoinColumn(name = "departmentID"),
			   inverseJoinColumns = @JoinColumn(name = "buildingID"))
	private List<Building> buildings;

	// Constructors
	public Department() {
		super();
	}
	
	public Department(String departmentName) {
		super();
		this.departmentName = departmentName;
	}
	
	public Long getDepartmentID() {
		return departmentID;
	}
	
	public String getDepartmentName() {
		return departmentName;
	}
	
	public void addEmployee(Employee employee) {
		employees.add(employee);
	}
	
	public void addDepartment(Building building) {
		buildings.add(building);
	}
	
	public void setEmployees(List<Employee> employeeList) {
		employees = employeeList;
	}
	
	public void setBuildings(List<Building> buildingList) {
		buildings = buildingList;
	}
	
}
