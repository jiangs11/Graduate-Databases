import java.io.Serializable;
import javax.persistence.*;
import java.util.*;

/**
 * Entity implementation class for Entity: Role
 *
 */
@Entity
@TableGenerator(name = "Role")
public class Role implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long roleID;
	
	private String roleName;
	
	@ManyToMany(mappedBy = "roles", cascade = CascadeType.PERSIST)
	private List<Employee> employees;
	
	// Constructors
	public Role() {
		super();
	}
	
	public Role(String roleName) {
		this.roleName = roleName;
	}
	
	public Long getRoleID() {
		return roleID;
	}
	
	public String getRoleName() {
		return roleName;
	}
	
	public void addEmployee(Employee employee) {
		employees.add(employee);
	}
	
	public void setEmployees(List<Employee> employeeList) {
		employees = employeeList;
	}
	
}
