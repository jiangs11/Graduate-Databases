import java.io.Serializable;
import javax.persistence.*;
import java.util.*;

/**
 * Entity implementation class for Entity: Building
 *
 */
@Entity
public class Building implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long buildingID;
	
	private String buildingName;
	
	private String city;
	
	@ManyToMany(mappedBy = "buildings", cascade = CascadeType.PERSIST)
	private List<Department> departments;
	
	@OneToMany
	@JoinTable(name = "building_floor",
	   		   joinColumns = @JoinColumn(name = "buildingID"),
	   		   inverseJoinColumns = @JoinColumn(name = "floorID"))
	private List<Floor> floors;

	// Constructors
	public Building() {
		super();
	}
	
	public Building(String buildingName, String city) {
		super();
		this.buildingName = buildingName;
		this.city = city;
	}
	
	public Long getBuildingID() {
		return buildingID;
	}
	
	public String getBuildingName() {
		return buildingName;
	}
	
	public String getCity() {
		return city;
	}
	
	public void addDepartment(Department department) {
		departments.add(department);
	}
	
	public void addFloor(Floor floor) {
		floors.add(floor);
	}
	
	public void setDepartments(List<Department> departmentList) {
		departments = departmentList;
	}
	
	public void setFloors(List<Floor> floorList) {
		floors = floorList;
	}
	
}
