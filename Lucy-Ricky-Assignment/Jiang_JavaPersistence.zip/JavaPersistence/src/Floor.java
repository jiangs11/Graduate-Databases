import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Floor
 *
 */
@Entity
@TableGenerator(name = "Floor")
public class Floor implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long floorID;
	
	private String floorNumber;
	
	private Integer numConfRooms;
	
	private Boolean dining;
	
	private Building building;
	
	// Constructors
	public Floor() {
		super();
	}
	
	public Floor(String floorNumber, Integer numConfRooms, Boolean dining, Building building) {
		super();
		this.floorNumber = floorNumber;
		this.numConfRooms = numConfRooms;
		this.dining = dining;
		this.building = building;
	}
	
	public Long getFloorID() {
		return floorID;
	}
	
	public String getFloorNumber() {
		return floorNumber;
	}
	
	public Integer getNumConfRooms() {
		return numConfRooms;
	}
	
	public Boolean getDining() {
		return dining;
	}
	
	public Building getBuilding() {
		return building;
	}
	
	public void setBuilding(Building newBuilding) {
		building = newBuilding;
	}
	
}
