import java.io.Serializable;
import javax.persistence.*;
import java.util.*;

/**
 * Entity implementation class for Entity: Employee
 *
 */
@Entity
@TableGenerator(name = "Employee")
public class Employee implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long employeeID;
	
	private String name;
	
	private Date hireDate;
	
	private Department department;
	
	@ManyToMany
	@JoinTable(name = "employee_role",
			   joinColumns = @JoinColumn(name = "employeeID"),
			   inverseJoinColumns = @JoinColumn(name = "roleID"))
	private List<Role> roles;
	
	
	// Constructors	
	public Employee() {
		super();
	}
	
	public Employee(String name, Date hireDate, Department department, Role role) {
		super();
		this.name = name;
		this.hireDate = hireDate;
		this.department = department;
		roles = new ArrayList<Role>();
		addRole(role);
	}
	
	public Long getEmployeeID() {
		return employeeID;
	}
	
	public String getName() {
		return name;
	}
	
	public Date getHireDate() {
		return hireDate;
	}
	
	public Department getDepartment() {
		return department;
	}
	
	public void setDepartment(Department newDepartment) {
		department = newDepartment;
	}
	
	public void addRole(Role role) {
		roles.add(role);
	}  
	
}
